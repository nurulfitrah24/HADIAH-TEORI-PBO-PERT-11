/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package orang;


import java.awt.*;
import java.awt.event.*;
public class Orang extends Frame implements ActionListener{
    int x = 100;
    int y = 100;
public static void main(String[] args) {
    Frame frame = new Orang();
    frame.setSize(640, 480);
    frame.setVisible(true);
}
public Orang() {
setTitle("Manusia");

// end program when window is closed
    WindowListener l = new WindowAdapter()  {
    public void windowClosing(WindowEvent ev) {
    System.exit(0);
    }
    };
this.addWindowListener(l);
// mouse event handler
MouseListener mouseListener = new MouseAdapter() {
public void mouseClicked(MouseEvent ev) {
    x = ev.getX();
    y = ev.getY();
    repaint();
}
};
addMouseListener(mouseListener);
}

public void paint(Graphics g) {

setBackground (Color.yellow);


     g.setColor(Color.PINK); 
     g.drawOval(200,200,400,400);
     g.fillOval(200,200,400,400);
    
     g.setColor(Color.PINK); 
     g.fillOval(150,350,100,100);
     g.fillOval(550,350,100,100);
    
     g.setColor(Color.DARK_GRAY); 
     g.drawLine(380, 50, 250, 300);
     g.drawLine(382, 50, 260, 300);
     g.drawLine(384, 50, 270, 300);
     g.drawLine(386, 50, 280, 300);
     g.drawLine(388, 50, 290, 300);
     g.drawLine(380, 50, 300, 300);
     g.drawLine(382, 50, 310, 300);
     g.drawLine(384, 50, 320, 300);
     g.drawLine(386, 50, 330, 300);
     g.drawLine(388, 50, 340, 300);
     g.drawLine(380, 50, 350, 300);
     g.drawLine(382, 50, 360, 300);
     g.drawLine(384, 50, 370, 300);
     g.drawLine(386, 50, 380, 300);
     g.drawLine(388, 50, 390, 300);
     g.drawLine(380, 50, 400, 300);
     g.drawLine(382, 50, 410, 300);
     g.drawLine(384, 50, 420, 300);
     g.drawLine(386, 50, 430, 300);
     g.drawLine(388, 50, 440, 300);
     g.drawLine(380, 50, 450, 300);
     g.drawLine(382, 50, 460, 300);
     g.drawLine(384, 50, 470, 300);
     g.drawLine(386, 50, 480, 300);
     g.drawLine(388, 50, 490, 300);
     g.drawLine(380, 50, 500, 300);
     g.drawLine(382, 50, 510, 300);
     g.drawLine(384, 50, 520, 300);
     g.drawLine(386, 50, 530, 300);
     g.drawLine(388, 50, 540, 300);
     g.drawLine(380, 50, 550, 300);
     
  
     g.setColor(Color.black); 
     g.drawOval(240,330,80,80);
     g.drawOval(480,330,80,80);
  
     g.drawOval(275,345,30,50); 
     g.fillOval(275,345,30,50);
    
     g.fillOval(515,345,30,50);
  
     g.setColor(Color.white);
     g.drawOval(287,350,15,15);
     g.fillOval(287,350,15,15);
     g.drawOval(527,350,15,15);
     g.fillOval(527,350,15,15);
  
     g.setColor(Color.white);    
     g.drawOval(290,400,220,180);
     g.fillOval(290,400,220,180);
    
     g.setColor(Color.pink);
     g.drawRect(290,400,220,90);
     g.fillRect(290,400,220,90);
  
     g.setColor(Color.black);
     g.drawLine(305,535,495,535);
     g.drawLine(345,490,345,568);
     g.drawLine(452,490,452,570);
     g.drawLine(400,490,400,580);
       

Font f = new Font ("Desain Orang",Font.BOLD, 20);
     g.setFont(f);
     g.setColor(Color.pink);
     g.drawString("Gamabar diatas sebenarnya tidak Mewakili Diriku Kak :( :(  ",200,680);
}
public void actionPerformed(ActionEvent ev) {
String command = ev.getActionCommand();
if ("Exit".equals(command)) {
System.exit(0);
}
}
}
